function setSrc(src) {
    document.getElementById('target').src = src;
}